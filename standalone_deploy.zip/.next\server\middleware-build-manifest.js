globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/CqKTB3NAWhZKX8BmgPfQC/_buildManifest.js",
    "static/CqKTB3NAWhZKX8BmgPfQC/_ssgManifest.js",
    "static/CqKTB3NAWhZKX8BmgPfQC/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/2mmpezlrfmbu5.js",
    "static/chunks/196x_tfexoucg.js",
    "static/chunks/2e_lrwr-bf1eq.js",
    "static/chunks/turbopack-16157-fov14rm.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
